-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: turismo
-- ------------------------------------------------------
-- Server version	5.7.19-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `lugares`
--

DROP TABLE IF EXISTS `lugares`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lugares` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Nombre` char(71) DEFAULT NULL,
  `Pais` char(25) DEFAULT NULL,
  `Provincia` char(25) DEFAULT NULL,
  `Ciudad` char(25) DEFAULT NULL,
  `latitud` char(25) DEFAULT NULL,
  `longitud` char(26) DEFAULT NULL,
  `Tipo` char(21) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lugares`
--

LOCK TABLES `lugares` WRITE;
/*!40000 ALTER TABLE `lugares` DISABLE KEYS */;
INSERT INTO `lugares` VALUES (1,'Banco de Loja','Ecuador','Loja','Loja','-39.981.143','-792.019.862','Bancos y Cooperativas'),(2,'BanEcuador','Ecuador','Loja','Loja','-39.962.408','-792.026.433','Bancos y Cooperativas'),(3,'Banco \"Guayaquil\"','Ecuador','Loja','Loja','-3.996.123','-792.009.437','Bancos y Cooperativas'),(4,'Banco \"Pichincha\"','Ecuador','Loja','Loja','-3.997.113','-792.011.878','Bancos y Cooperativas'),(5,'Banco Internacional','Ecuador','Loja','Loja','-40.002.813','-792.019.368','Bancos y Cooperativas'),(6,'Agencia Banco de Loja','Ecuador','Loja','Loja','-39.964.804','-792.064.707','Bancos y Cooperativas'),(7,'Banco Del Pacífico S.A.','Ecuador','Loja','Loja','-39.822.546','-7.920.493','Bancos y Cooperativas'),(8,'Banco Solidario','Ecuador','Loja','Loja','-39.963.649','-792.036.266','Bancos y Cooperativas'),(9,'Produbanco','Ecuador','Loja','Loja','-39.963.809','-792.012.775','Bancos y Cooperativas'),(10,'Banco de Machala','Ecuador','Loja','Loja','-39.963.006','-79.202.228','Bancos y Cooperativas'),(11,'Cooperativa Financiera Padre Julián Lorente Ltda.','Ecuador','Loja','Loja','-40.011.912','-791.995.072','Bancos y Cooperativas'),(12,'Banco Del Austro','Ecuador','Loja','Loja','-39.961.937','-792.009.094','Bancos y Cooperativas'),(13,'Wester Union','Ecuador','Loja','Loja','-39.973.876','-79.203.165','Bancos y Cooperativas'),(14,'BancoDesarrollo','Ecuador','Loja','Loja','-39.788.984','-792.035.183','Bancos y Cooperativas'),(15,'Qbe Seguros','Ecuador','Loja','Loja','-39.926.255','-792.008.388','Bancos y Cooperativas'),(16,'Banco del Austro','Ecuador','Loja','Loja','-3.987.006','-793.583.315','Bancos y Cooperativas'),(17,'Cooperativa de ahorro y credito Fortuna','Ecuador','Loja','Loja','-39.941.141','-792.021.766','Bancos y Cooperativas'),(18,'29 DE OCTUBRE - Cooperativa de ahorro y crédito ltda.','Ecuador','Loja','Loja','-39.916.178','-792.025.265','Bancos y Cooperativas'),(19,'CACEL - Cooperativa de ahorro y crédito educadores de Loja','Ecuador','Loja','Loja','-39.998.341','-792.019.753','Bancos y Cooperativas'),(20,'JEP - Cooperativa de ahorro y crédito Juventud Ecuatoriana Progresista','Ecuador','Loja','Loja','-40.017.941','-792.036.117','Bancos y Cooperativas'),(21,'CAPILLA DE LA DOLOROSA','Ecuador','Loja','Loja','-39.965.399','-791.998.909','Iglesias'),(22,'IGLESIA LA CATEDRAL','Ecuador','Loja','Loja','-39.964.969','-792.010.966','Iglesias'),(23,'IGLESIA DE BELEN LA SAGRADA FAMILIA','Ecuador','Loja','Loja','-39.782.887','-792.249.703','Iglesias'),(24,'IGLESIA DE SAN FRANCISCO DE ASIS','Ecuador','Loja','Loja','-39.949.313','-792.016.281','Iglesias'),(25,'IGLESIA DE SAN ISIDRO LABRADOR','Ecuador','Loja','Loja','-40.284.413','-792.025.027','Iglesias'),(26,'IGLESIA DE SAN SEBASTIAN','Ecuador','Loja','Loja','-40.020.329','-792.014.936','Iglesias'),(27,'IGLESIA DE SANTO DOMINGO','Ecuador','Loja','Loja','-39.983.813','-792.013.568','Iglesias'),(28,'IGLESIA DEL PERPETUO SOCORRO','Ecuador','Loja','Loja','-40.036.564','-792.055.477','Iglesias'),(29,'LA IGLESIA DE LAS MADRES CONCEPTAS','Ecuador','Loja','Loja','-39.972.864','-792.008.782','Iglesias'),(30,'LA IGLESIA DE SAN PEDRO','Ecuador','Loja','Loja','-40.065.956','-792.074.259','Iglesias'),(31,'LA IGLESIA DEL VALLE','Ecuador','Loja','Loja','-39.814.019','-79.201.344','Iglesias'),(32,'Iglesia del Divino Niño','Ecuador','Loja','Loja','-40.102.164','-79.215.492','Iglesias'),(33,'IGLESIA DEL PEDESTAL','Ecuador','Loja','Loja','-39.952.775','-792.082.487','Iglesias'),(34,'VIRGEN DE LOS DOLORES CARIGAN','Ecuador','Loja','Loja','-39.592.198','-792.414.283','Iglesias'),(35,'\"CRISTO REY','Ecuador','Loja','Loja','-39.699.497','-792.085.665','Iglesias'),(36,'IGLESIA DE BOLONIA','Ecuador','Loja','Loja','-39.953.243','-792.380.655','Iglesias'),(37,'IGLESIA CLODOVEO JARAMILLO','Ecuador','Loja','Loja','-39.822.555','-792.128.997','Iglesias'),(38,'Iglesia la pradera','Ecuador','Loja','Loja','-40.137.175','-791.995.282','Iglesias'),(39,'Iglesia de la daniel alvarez','Ecuador','Loja','Loja','-40.185.577','-792.111.294','Iglesias'),(40,'“NUESTRA SEÑORA DEL ROSARIO','Ecuador','Loja','Loja','-4.007.027','-791.867.689','Iglesias'),(41,'SANTO EVANGELIO” (SEÑOR CAUTIVO)','Ecuador','Loja','Loja','-39.480.007','-792.150.944','Iglesias'),(42,'SAN CAYETANO','Ecuador','Loja','Loja','-3.985.665','-791.976.768','Iglesias'),(43,'Iglesia de zamora huayco','Ecuador','Loja','Loja','-40.071.655','-791.868.165','Iglesias'),(44,'Salón Lolita','Ecuador','Loja','Loja','-39.810.229','-792.015.606','Restaurantes'),(45,'Riscomar','Ecuador','Loja','Loja','-39.979.425','-792.022.875','Restaurantes'),(46,'VidaVentura grill&sports','Ecuador','Loja','Loja','-39.935.169','-792.024.029','Restaurantes'),(47,'Casa Sol','Ecuador','Loja','Loja','-39.960.657','-792.025.049','Restaurantes'),(48,'Mama Lola','Ecuador','Loja','Loja','-39.779.515','-792.010.101','Restaurantes'),(49,'Dumas Trattoria & Restaurant','Ecuador','Loja','Loja','-39.961.749','-792.012.017','Restaurantes'),(50,'Parrilladas el Fogon','Ecuador','Loja','Loja','-39.762.369','-792.043.956','Restaurantes'),(51,'Toro Rojo Steakhouse','Ecuador','Loja','Loja','-4.001.276','-791.988.834','Restaurantes'),(52,'Arsenia Restaurante','Ecuador','Loja','Loja','-39.934.085','-792.014.081','Restaurantes'),(53,'OINK Bar & Grill','Ecuador','Loja','Loja','-3.998.412','-791.980.375','Restaurantes'),(54,'El Tamal Lojano','Ecuador','Loja','Loja','-40.009.229','-791.976.437','Restaurantes'),(55,'CBC - California Burrito Co','Ecuador','Loja','Loja','-40.096.549','-792.029.457','Restaurantes'),(56,'El Carbonero','Ecuador','Loja','Loja','-39.987.764','-791.981.429','Restaurantes'),(57,'Asadero Los Naranjos','Ecuador','Loja','Loja','-39.822.757','-792.016.578','Restaurantes'),(58,'Deja Vu Restaurant','Ecuador','Loja','Loja','-39.967.127','-792.012.277','Restaurantes'),(59,'Parrilladas Uruguayas','Ecuador','Loja','Loja','-3.991.856','-792.051.006','Restaurantes'),(60,'Sushi Cat','Ecuador','Loja','Loja','-39.940.778','-791.985.277','Restaurantes'),(61,'Mar Rojo Restaurante','Ecuador','Loja','Loja','-39.958.867','-791.976.059','Restaurantes');
/*!40000 ALTER TABLE `lugares` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-07-27 13:55:34
